Scalable Vector Graphics (SVG)
==============================

Create Scalable Vector Graphics (SVG) directly from Search Processing Language (SPL)